﻿#include "Header.h"

string** storeBackground(string MODE)
{
    fstream fs;

    if (MODE == "EASY")
        fs.open("easy.txt", ios::in);
    else
        if (MODE == "MEDIUM")
            fs.open("medium.txt", ios::in);
        else
            if (MODE == "HARD")
                fs.open("hard.txt", ios::in);


    if (!fs.is_open())
    {
        cout << "Can't open file background";
        exit(0);
    }

    string temp;

    int SIZE = EASY;
    if (MODE == "MEDIUM") 
        SIZE = MEDIUM;
    else
        if (MODE == "HARD")
            SIZE = HARD;

    string** bg = new string * [SIZE * 3];
    for (int i = 0; i < SIZE * 3; i++) {
        bg[i] = new string[SIZE];
    }

    for (int i = 0; i < SIZE * 3; i++) // Number of rows in matrix
    {
        getline(fs, temp);
        for (int j = 0; j < SIZE; j++) // Number of columns in matrix
            bg[i][j] = temp.substr(j * 7, 7);
    }

    fs.close();
    
    return bg;
}

void drawBackground(int SIZE, string** bg, int i, int j)
{
    setColor(BRIGHT_WHITE, BLACK);
    int xCo = calCubeWidth(j + 1);
    int yCo = calCubeHeight(i + 1);

    for (int k = 0; k < 3; k++)
    {
        moveCursorToXY(xCo, yCo++);
        cout << bg[i * 3 + k][j];
    }
}

void drawHeader() {
    cout << "+-----+";
}

void drawFooter() {
    cout << "+-----+";
}

void drawRowMid(char** Letters, int i, int j) {
    cout << "|  " << Letters[i][j] << "  |";
}

void drawRowMidChosen(char** Letters, int i, int j) {
    cout << "| [" << Letters[i][j] << "] |";
}

void printSpace() {
    cout << "       ";
}

void drawHorizontalLine(int x1, int x2)
{
    if (x1 > x2)
        swap(x1, x2);
    int length = x2 - x1;
    for (int i = 1; i < length; i++)
        cout << "-------";
}

void drawVerticalLine(int x1, int y1, int x2, int y2)
{
    if (y1 > y2)
        swap(y1, y2);
    int length = y2 - y1;

    int xCo = calCubeWidth(x1) + 3; //Coordinate
    int yCo = calCubeHeight(y1) + 2;

    for (int i = 1; i < length; i++)
        for (int j = 1; j <= 3; j++) {
            moveCursorToXY(xCo, yCo + j + (i - 1) * 3);
            cout << "|";
        }
}

void drawILine(Cube p1, Cube p2, char** Letters)
{
    setColor(RED, BRIGHT_WHITE);
    if (p1.y == p2.y) //Cùng dòng
    {
        movetoMiddleRightCube(p1);
        cout << "=";

        drawHorizontalLine(p1.x, p2.x);
        cout << "=";
    }

    if (p1.x == p2.x) //Cùng cột
    {
        movetoMiddleBotCube(p1);
        cout << "=";

        drawVerticalLine(p1.x, p1.y, p2.x, p2.y);

        movetoMiddleTopCube(p2);
        cout << "=";
    }
    moveCursorToXY(15 + 60, 9);
    cout << "I MATCHING";
    Sleep(600);
    setColor(BRIGHT_WHITE, BLACK);
}

void drawLLine(Cube p1, Cube p2, char** Letters)
{
    setColor(RED, BRIGHT_WHITE);
    int xCo, yCo; // Coordinate
    if (p1.y > p2.y) 
    {
        if (checkY(p1.x, p1.y, p2.x, p1.y, Letters) && checkX(p2.x, p1.y, p2.x, p2.y, Letters) && Letters[p1.y][p2.x] == ' ') { //ngang -> dọc
            movetoMiddleRightCube(p1);
            cout << "=---";

            drawHorizontalLine(p1.x, p2.x);

            cout << "+";

            xCo = calCubeWidth(p2.x) + 3;
            yCo = calCubeHeight(p1.y) + 1;
            moveCursorToXY(xCo, yCo - 1);
            cout << "|";

            drawVerticalLine(p2.x, p1.y, p2.x, p2.y);

            movetoMiddleBotCube(p2); 
            cout << "=";
        }
        else
            if (checkX(p1.x, p1.y, p1.x, p2.y, Letters) && checkY(p1.x, p2.y, p2.x, p2.y, Letters) && Letters[p2.y][p1.x] == ' ') { //dọc -> ngang
                movetoMiddleTopCube(p1);
                cout << "=";

                xCo = calCubeWidth(p1.x) + 3;
                yCo = calCubeHeight(p2.y) + 2;
                moveCursorToXY(xCo, yCo);
                cout << "|";

                drawVerticalLine(p1.x, p1.y, p2.x, p2.y);

                moveCursorToXY(xCo, yCo - 1);
                cout << "+---";
                drawHorizontalLine(p1.x, p2.x);

                movetoMiddleLeftCube(p2);
                cout << "=";
            }
    }
    else
        {
            if (checkY(p1.x, p1.y, p2.x, p1.y, Letters) && checkX(p2.x, p1.y, p2.x, p2.y, Letters) && Letters[p1.y][p2.x] == ' ') { //ngang -> dọc
                movetoMiddleRightCube(p1);
                cout << "=---";

                drawHorizontalLine(p1.x, p2.x);

                cout << "+";

                xCo = calCubeWidth(p2.x) + 3;
                yCo = calCubeHeight(p1.y) + 1;
                moveCursorToXY(xCo, yCo + 1);
                cout << "|";

                drawVerticalLine(p2.x, p1.y, p2.x, p2.y);
                
                movetoMiddleTopCube(p2);
                cout << "=";
            }
            else
                if (checkX(p1.x, p1.y, p1.x, p2.y, Letters) && checkY(p1.x, p2.y, p2.x, p2.y, Letters) && Letters[p2.y][p1.x] == ' ') { //dọc -> ngang
                    movetoMiddleBotCube(p1);
                    cout << "=";

                    drawVerticalLine(p1.x, p1.y, p2.x, p2.y);

                    xCo = calCubeWidth(p1.x) + 3;
                    yCo = calCubeHeight(p2.y);
                    moveCursorToXY(xCo, yCo);
                    cout << "|";

                    moveCursorToXY(xCo, yCo + 1);
                    cout << "+---";
                    drawHorizontalLine(p1.x, p2.x);

                    movetoMiddleLeftCube(p2);
                    cout << "=";
                }
        }
    moveCursorToXY(15 + 60, 9);
    cout << "L MATCHING";
    Sleep(600);
    setColor(BRIGHT_WHITE, BLACK);
}

void drawZLine(Cube p1, Cube p2, char** Letters)
{
    setColor(RED, BRIGHT_WHITE);
    int xCo, yCo;
    if (p1.y > p2.y)
    {   
        //dọc -> ngang -> dọc
        for (int y = p2.y + 1; y < p1.y; y++) 
        {
            if (checkX(p2.x, p2.y, p2.x, y, Letters) && checkY(p2.x, y, p1.x, y, Letters) && checkX(p1.x, y, p1.x, p1.y, Letters)
                && Letters[y][p2.x] == ' ' && Letters[y][p1.x] == ' ') { 

                xCo = calCubeWidth(p1.x) + 3;
                yCo = calCubeHeight(y) + 2;

                movetoMiddleTopCube(p1);
                cout << "=";

                drawVerticalLine(p2.x, p2.y, p2.x, y);

                moveCursorToXY(xCo, yCo );
                cout << "|";

                moveCursorToXY(xCo, yCo - 1);
                cout << "+---";

                drawHorizontalLine(p1.x, p2.x);

                cout << "---+";

                drawVerticalLine(p1.x, y, p1.x, p1.y);

                xCo = calCubeWidth(p2.x) + 3;
                yCo = calCubeHeight(y);

                moveCursorToXY(xCo, yCo);
                cout << "|";

                movetoMiddleBotCube(p2);
                cout << "=";

                moveCursorToXY(15 + 60, 9);
                cout << "Z MATCHING";
                Sleep(600);
                setColor(BRIGHT_WHITE, BLACK);
                return;
            }
        }
        //ngang -> dọc -> ngang
        for (int x = p1.x + 1; x < p2.x; x++) {
            if (checkY(p1.x, p1.y, x, p1.y, Letters) && checkX(x, p1.y, x, p2.y, Letters) && checkY(x, p2.y, p2.x, p2.y, Letters)
                && Letters[p1.y][x] == ' ' && Letters[p2.y][x] == ' ') { 

                movetoMiddleRightCube(p1);
                cout << "=---";

                drawHorizontalLine(p1.x, x);

                xCo = calCubeWidth(x) + 3;
                yCo = calCubeHeight(p1.y) + 1;
                
                moveCursorToXY(xCo, yCo);
                cout << "+";
                moveCursorToXY(xCo, yCo - 1);
                cout << "|";

                drawVerticalLine(x, p1.y, x, p2.y);

                yCo = calCubeHeight(p2.y) + 1;

                moveCursorToXY(xCo, yCo + 1);
                cout << "|";
                moveCursorToXY(xCo, yCo);
                cout << "+---";
                
                drawHorizontalLine(x, p2.x);

                movetoMiddleLeftCube(p2);
                cout << "=";

                moveCursorToXY(15 + 60, 9);
                cout << "Z MATCHING";
                Sleep(600);
                setColor(BRIGHT_WHITE, BLACK);
                return;
            }
        }
    }
    else
    {
        //dọc -> ngang -> dọc
        for (int y = p1.y + 1; y < p2.y; y++)
        {
            if (checkX(p2.x, p2.y, p2.x, y, Letters) && checkY(p2.x, y, p1.x, y, Letters) && checkX(p1.x, y, p1.x, p1.y, Letters)
                && Letters[y][p2.x] == ' ' && Letters[y][p1.x] == ' ') {

                xCo = calCubeWidth(p1.x) + 3;
                yCo = calCubeHeight(y);

                movetoMiddleBotCube(p1);
                cout << "=";

                drawVerticalLine(p2.x, p2.y, p2.x, y);

                moveCursorToXY(xCo, yCo);
                cout << "|";

                moveCursorToXY(xCo, yCo + 1);
                cout << "+---";

                drawHorizontalLine(p1.x, p2.x);

                cout << "---+";

                drawVerticalLine(p1.x, y, p1.x, p1.y);

                xCo = calCubeWidth(p2.x) + 3;
                yCo = calCubeHeight(y) + 2;

                moveCursorToXY(xCo, yCo);
                cout << "|";

                movetoMiddleTopCube(p2);
                cout << "=";
                
                moveCursorToXY(15 + 60, 9);
                cout << "Z MATCHING";
                Sleep(600);
                setColor(BRIGHT_WHITE, BLACK);
                return;
            }
        }
        //ngang -> dọc -> ngang
        for (int x = p1.x + 1; x < p2.x; x++) {
            if (checkY(p1.x, p1.y, x, p1.y, Letters) && checkX(x, p1.y, x, p2.y, Letters) && checkY(x, p2.y, p2.x, p2.y, Letters)
                && Letters[p1.y][x] == ' ' && Letters[p2.y][x] == ' ') {

                movetoMiddleRightCube(p1);
                cout << "=---";

                drawHorizontalLine(p1.x, x);

                xCo = calCubeWidth(x) + 3;
                yCo = calCubeHeight(p1.y) + 1;

                moveCursorToXY(xCo, yCo);
                cout << "+";
                moveCursorToXY(xCo, yCo + 1);
                cout << "|";

                drawVerticalLine(x, p1.y, x, p2.y);

                yCo = calCubeHeight(p2.y);

                moveCursorToXY(xCo, yCo);
                cout << "|";
                moveCursorToXY(xCo, yCo + 1);
                cout << "+---";

                drawHorizontalLine(x, p2.x);

                movetoMiddleLeftCube(p2);
                cout << "=";

                moveCursorToXY(15 + 60, 9);
                cout << "Z MATCHING";
                Sleep(600);
                setColor(BRIGHT_WHITE, BLACK);
                return;
            }
        }
    }
    setColor(BRIGHT_WHITE, BLACK);
}

void drawULine(Cube p1, Cube p2, char** Letters, int SIZE_BOARD)
{
    setColor(RED, BRIGHT_WHITE);
    int xCo, yCo;
    Cube pMinY = p1, pMaxY = p2;
    if (p1.y > p2.y) {
        pMinY = p2;
        pMaxY = p1;
    }

    for (int y = pMinY.y - 1; y >= 0; y--) { //U ngửa dưới                      
        if (checkX(pMinY.x, pMinY.y, pMinY.x, y, Letters) && checkY(pMinY.x, y, pMaxY.x, y, Letters) && checkX(pMaxY.x, y, pMaxY.x, pMaxY.y, Letters)
            && Letters[y][pMinY.x] == ' ' && Letters[y][pMaxY.x] == ' ') {

            xCo = calCubeWidth(pMinY.x) + 3;
            yCo = calCubeHeight(y) + 2;

            movetoMiddleTopCube(pMinY);
            cout << "=";

            drawVerticalLine(pMaxY.x, pMaxY.y, pMaxY.x, y);
            
            moveCursorToXY(xCo, yCo);
            cout << "|";

            if (pMinY.x < pMaxY.x) {
                xCo = calCubeWidth(pMinY.x) + 3;
                yCo = calCubeHeight(y) + 2;

                moveCursorToXY(xCo, yCo - 1);
                cout << "+---";

                drawHorizontalLine(pMinY.x, pMaxY.x);

                cout << "---+";
            }
            else
            {
                xCo = calCubeWidth(pMaxY.x) + 3;
                yCo = calCubeHeight(y) + 2;

                moveCursorToXY(xCo, yCo - 1);
                cout << "+---";

                drawHorizontalLine(pMinY.x, pMaxY.x);

                cout << "---+";
            }

            xCo = calCubeWidth(pMaxY.x) + 3;
            yCo = calCubeHeight(y) + 2;

            moveCursorToXY(xCo, yCo);
            cout << "|";
   
            drawVerticalLine(pMinY.x, y, pMinY.x, pMinY.y);            
            
            movetoMiddleTopCube(pMaxY);
            cout << "=";

            moveCursorToXY(15 + 60, 10);
            cout << "U MATCHING";
            Sleep(600);
            setColor(BRIGHT_WHITE, BLACK);
            return;
        }
    }

    for (int y = pMinY.y + 1; y < SIZE_BOARD; y++) { //U ngửa trên                      
        if (checkX(pMinY.x, pMinY.y, pMinY.x, y, Letters) && checkY(pMinY.x, y, pMaxY.x, y, Letters) && checkX(pMaxY.x, y, pMaxY.x, pMaxY.y, Letters)
            && Letters[y][pMinY.x] == ' ' && Letters[y][p2.x] == ' ') {

            movetoMiddleBotCube(pMinY);
            cout << "=";

            if (pMinY.x <= pMaxY.x) {
                xCo = calCubeWidth(pMinY.x) + 3;
                yCo = calCubeHeight(y);
                drawVerticalLine(pMaxY.x, pMaxY.y, pMaxY.x, y);
                moveCursorToXY(xCo, yCo);
                cout << "|";

                moveCursorToXY(xCo, yCo + 1);
                cout << "+---";

                drawHorizontalLine(pMinY.x, pMaxY.x);

                cout << "---+";

                drawVerticalLine(pMinY.x, y, pMinY.x, pMinY.y);

                xCo = calCubeWidth(pMaxY.x) + 3;
                yCo = calCubeHeight(y);

                moveCursorToXY(xCo, yCo);
                cout << "|";
            }
            else
            {
                xCo = calCubeWidth(pMaxY.x) + 3;
                yCo = calCubeHeight(y);

                moveCursorToXY(xCo, yCo);
                cout << "|";

                drawVerticalLine(pMaxY.x, pMaxY.y, pMaxY.x, y);

                moveCursorToXY(xCo, yCo + 1);
                cout << "+---";

                drawHorizontalLine(pMinY.x, pMaxY.x);

                cout << "---+";

                drawVerticalLine(pMinY.x, pMinY.y, pMinY.x, y);

                xCo = calCubeWidth(pMinY.x) + 3;
                yCo = calCubeHeight(y);

                moveCursorToXY(xCo, yCo);
                cout << "|";
            }

            movetoMiddleBotCube(pMaxY);
            cout << "=";

            moveCursorToXY(15 + 60, 9);
            cout << "U MATCHING";
            Sleep(600);
            setColor(BRIGHT_WHITE, BLACK);
            return;
        }
    }

    for (int x = p1.x - 1; x >= 0; x--) { //U ngửa phải
        if (checkY(p1.x, p1.y, x, p1.y, Letters) && checkX(x, p1.y, x, p2.y, Letters) && checkY(x, p2.y, p2.x, p2.y, Letters)
            && Letters[p1.y][x] == ' ' && Letters[p2.y][x] == ' ') {

            xCo = calCubeWidth(x) + 3;
            yCo = calCubeHeight(p1.y) + 1;

            movetoMiddleLeftCube(p1);
            cout << "=";

            moveCursorToXY(xCo, yCo);
            cout << "+---";

            drawHorizontalLine(x, p1.x);

            drawVerticalLine(x, p1.y, x, p2.y);

            if (p1.y > p2.y) {
                moveCursorToXY(xCo, yCo - 1);
                cout << "|";

                yCo = calCubeHeight(p2.y);
                moveCursorToXY(xCo, yCo + 2);
                cout << "|";
            }
            else {
                moveCursorToXY(xCo, yCo + 1);
                cout << "|";

                yCo = calCubeHeight(p2.y);
                moveCursorToXY(xCo, yCo);
                cout << "|";
            }

            moveCursorToXY(xCo, yCo + 1);
            cout << "+---";

            drawHorizontalLine(x, p2.x);

            movetoMiddleLeftCube(p2);
            cout << "=";

            moveCursorToXY(15 + 60, 9);
            cout << "U MATCHING";
            Sleep(600);
            setColor(BRIGHT_WHITE, BLACK);
            return;
        }
    }

    for (int x = p1.x + 1; x < SIZE_BOARD; x++) { //U ngửa trái
        if (checkY(p1.x, p1.y, x, p1.y, Letters) && checkX(x, p1.y, x, p2.y, Letters) && checkY(x, p2.y, p2.x, p2.y, Letters)
            && Letters[p1.y][x] == ' ' && Letters[p2.y][x] == ' ') {

            movetoMiddleRightCube(p1);
            cout << "=---";

            drawHorizontalLine(p1.x, x);

            xCo = calCubeWidth(x) + 3;
            yCo = calCubeHeight(p1.y) + 1;

            moveCursorToXY(xCo, yCo);
            cout << "+";
            

            drawVerticalLine(x, p1.y, x, p2.y);

            if (p1.y > p2.y) {
                moveCursorToXY(xCo, yCo - 1);
                cout << "|";
                
                yCo = calCubeHeight(p2.y);
                moveCursorToXY(xCo, yCo + 2);
                cout << "|";
            }
            else {
                moveCursorToXY(xCo, yCo + 1);
                cout << "|";

                yCo = calCubeHeight(p2.y);
                moveCursorToXY(xCo, yCo);
                cout << "|";
            }
            
            moveCursorToXY(xCo, yCo + 1);
            cout << "+";
            movetoMiddleRightCube(p2);
            cout << "=---";
            drawHorizontalLine(p2.x, x);
            
            moveCursorToXY(15 + 60, 9);
            cout << "U MATCHING";
            Sleep(600);
            setColor(BRIGHT_WHITE, BLACK);
            return;
        }
    }
}

void drawBackgroundDeleted(string** bg, int i, int j)
{
    cout << bg[i * 3 + 1][j];
}
//Set lại màu trắng cho Cube
void drawCube(char** Letters, string** bg, Cube previous)
{
    int x = calCubeWidth(previous.x);
    int y = calCubeHeight(previous.y) + 1;
    setColor(BRIGHT_WHITE, BLACK);
    if (Letters[previous.y][previous.x] == ' ') {
        moveCursorToXY(x, y); drawBackgroundDeleted(bg, previous.y - 1, previous.x - 1);
    }
    else {
        moveCursorToXY(x, y); drawRowMid(Letters, previous.y, previous.x);
    }
}

//Set blue cho Cube đang trỏ tới
void drawCubeChosen(char** Letters, string** bg, Cube selecting)
{
    int x = calCubeWidth(selecting.x);
    int y = calCubeHeight(selecting.y) + 1;
    setColor(BLUE, BRIGHT_WHITE);
    if (Letters[selecting.y][selecting.x] == ' ') {
        moveCursorToXY(x, y); drawBackgroundDeleted(bg, selecting.y - 1, selecting.x - 1);
    }
    else {
        moveCursorToXY(x, y); drawRowMidChosen(Letters, selecting.y, selecting.x); 
    }
    setColor(BRIGHT_WHITE, BLACK);
}

//Set màu đỏ cho Cube bị lock
void drawCubeLock(char** Letters, Cube selected)
{
    int x = calCubeWidth(selected.x);
    int y = calCubeHeight(selected.y) + 1;
    setColor(RED, BRIGHT_WHITE);
    moveCursorToXY(x, y); drawRowMidChosen(Letters, selected.y, selected.x); 
        
    setColor(BRIGHT_WHITE, BLACK);
}

//Set green cho Cube suggest
void drawCubeSuggest(char** Letters, Cube suggested)
{
    int x = calCubeWidth(suggested.x);
    int y = calCubeHeight(suggested.y) + 1;
    setColor(GREEN, BRIGHT_WHITE);
    moveCursorToXY(x, y); drawRowMidChosen(Letters, suggested.y, suggested.x);
        
    setColor(BRIGHT_WHITE, BLACK);
}

void drawBoard(char** Letters, string** bg, int SIZE, int SIZE_BOARD)
{
    SetConsoleOutputCP(65001);
    setColor(BRIGHT_WHITE, BLACK);
    for (int i = 0; i < SIZE_BOARD; i++) {
        for (int j = 0; j < SIZE_BOARD; j++) {
            if (Letters[i][j] != ' ') //Nếu cube đó không phải chữ cái thì không hiển thị
                drawHeader();
            else
                printSpace();
        }

        cout << endl;

        for (int j = 0; j < SIZE_BOARD; j++) {
            if (Letters[i][j] != ' ')
                drawRowMid(Letters, i, j);
            else
                printSpace();
        }

        cout << endl;

        for (int j = 0; j < SIZE_BOARD; j++) {
            if (Letters[i][j] != ' ')
                drawFooter();
            else
                printSpace();
        }

        cout << endl;
    }

    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            if (Letters[i + 1][j + 1] == ' ')
                drawBackground(SIZE, bg, i, j);
                
        }
    }
}


Cube Selecting(char** Letters, string** bg, int SIZE, Cube selecting, Cube lockCube, Cube help1, Cube help2, int &score)
{
    while (true) {
        if (selecting.y != lockCube.y || selecting.x != lockCube.x) //Không đổi màu ô bị lock
            drawCubeChosen(Letters, bg, selecting);

        Cube previous = { selecting.y, selecting.x };
        switch (inputKeyboard()) {
        case 1:  // move Up
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            if (previous.y != lockCube.y || previous.x != lockCube.x) //Nếu là ô bị lock thì không cần set lại màu
                drawCube(Letters, bg, previous); //Set lại màu trắng cho ô đã di chuyển qua trước đó

            if (selecting.y > 1)
                selecting.y -= 1;
            else
                selecting.y = SIZE;
            break;
        case 2:  // move Left
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            if (previous.y != lockCube.y || previous.x != lockCube.x)
                drawCube(Letters, bg, previous);

            if (selecting.x > 1)
                selecting.x -= 1;
            else
                selecting.x = SIZE;
            break;
        case 3:  // move Right
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            if (previous.y != lockCube.y || previous.x != lockCube.x)
                drawCube(Letters, bg, previous);

            if (selecting.x < SIZE)
                selecting.x += 1;
            else
                selecting.x = 1;
            break;
        case 4:  // move Down
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            if (previous.y != lockCube.y || previous.x != lockCube.x)
                drawCube(Letters, bg, previous);

            if (selecting.y < SIZE)
                selecting.y += 1;
            else
                selecting.y = 1;
            break;
        case 5:  // Enter
            PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
            Sleep(50);
            if (Letters[selecting.y][selecting.x] != ' ')
                return selecting;
            else
            {
                moveCursorToXY(69, 9);
                setColor(RED, BRIGHT_WHITE);
                cout << "CAN'T SELECT BLANK CUBE";
                setColor(BRIGHT_WHITE, BLACK);
                Sleep(2000);
                moveCursorToXY(69, 10);
                cout << "                       ";
            }
            break;
        case 6: // Help 
            score -= 2;
            setColor(BRIGHT_WHITE, AQUA);
            moveCursorToXY(69, 7);
            cout << "   "; //Delete previous score
            moveCursorToXY(69, 7);
            cout << score; //Print new score
            drawCubeSuggest(Letters, help1);
            drawCubeSuggest(Letters, help2);
            Sleep(800);
            drawCube(Letters, bg, help1);
            drawCube(Letters, bg, help2);
            if ((help1.x == lockCube.x && help1.y == lockCube.y || help2.x == lockCube.x && help2.y == lockCube.y))
                drawCubeLock(Letters, lockCube);
        default:
            break;
        }
    }
}

bool checkMatch(Cube p1, Cube p2, char** Letters, string MODE, int SIZE, int SIZE_BOARD, int &score, int &time)
{
    if ((p1.y == p2.y) && (p1.x == p2.x))
    {
        setColor(RED, BRIGHT_WHITE);
        moveCursorToXY(9 + 60, 9);
        cout << "CAN'T SELECT SAME CUBE";
        Sleep(600);
        setColor(BRIGHT_WHITE, BLACK);
        return false;
    }
    else
        if ((Letters[p1.y][p1.x] == Letters[p2.y][p2.x]) && (Letters[p1.y][p1.x] != ' ')) {
            if (checkI(p1, p2, Letters)) {
                drawILine(p1, p2, Letters); 
                score += 1;
                Letters[p1.y][p1.x] = Letters[p2.y][p2.x] = ' '; //Thay chữ cái thành ' ' để xóa Cube
                return true;
            }
            else
                if (checkL(p1, p2, Letters)) {
                    drawLLine(p1, p2, Letters);
                    score += 2;
                    Letters[p1.y][p1.x] = Letters[p2.y][p2.x] = ' ';
                    return true;
                }
                else
                    if (checkZ(p1, p2, Letters)) {
                        drawZLine(p1, p2, Letters);
                        score += 3;
                        Letters[p1.y][p1.x] = Letters[p2.y][p2.x] = ' ';
                        return true;
                    }
                    else
                        if (checkU(p1, p2, Letters, SIZE_BOARD)) {
                            drawULine(p1, p2, Letters, SIZE_BOARD);
                            score += 4;
                            Letters[p1.y][p1.x] = Letters[p2.y][p2.x] = ' ';
                            return true;
                        }
                        else
                        {   //2 ô được chọn không connect được với nhau
                            moveCursorToXY(13 + 60, 9);
                            setColor(RED, BRIGHT_WHITE);
                            cout << "CAN'T CONNECT"; 
                            score -= 3;
                            Sleep(1000);
                            setColor(BRIGHT_WHITE, BLACK);
                            return false;
                        }
        }
        else
        {   //2 ô được chọn không giống nhau
            moveCursorToXY(15 + 60, 9);
            setColor(RED, BRIGHT_WHITE);
            cout << "NOT MATCH";
            score -= 3;
            Sleep(1000);
            setColor(BRIGHT_WHITE, BLACK);
            return false;
        }
}

void Matching(char** Letters, string** bg, string MODE, int SIZE, int SIZE_BOARD, Player &player)
{
    Cube firstCube, secondCube, lockCube, help1, help2;
    int score = 0, time = 0;
    lockCube = { 0, 0 }; //Ban đầu không có ô nào bị lock
    secondCube = { 1, 1 }; //Vị trí ban đầu của con trỏ là tại ô 1,1
    int cube = SIZE * SIZE; //Số lượng cube
    
    do {
        getLetters(Letters, SIZE, SIZE_BOARD);
    } while (!canSolve(Letters, SIZE, SIZE_BOARD, help1, help2));

    std::time_t start_time = std::time(nullptr); //Bắt đầu đếm giờ chơi game

    while (cube != 0)
    {   
        while (!canSolve(Letters, SIZE, SIZE_BOARD, help1, help2))
        {
            if (MODE == "EASY")  //Nếu để bảng bị Shuffle thì sẽ trừ điểm
                score -= 0;
            else 
                if (MODE == "MEDIUM")
                    score -= 3;
                else
                    if (MODE == "HARD")
                        score -= 5;

            system("cls");
            drawBoard(Letters, bg, SIZE, SIZE_BOARD); //In lại board sau khi xóa 2 cặp trước để người chơi quan sát
            printInterface(player, score);
            moveCursorToXY(66, 9);
            setColor(RED, BRIGHT_WHITE);
            cout << "NO MOVES LEFT - SHUFFLE BOARD";
            moveCursorToXY(0, 27);
            Sleep(2000);
            setColor(BRIGHT_WHITE, BLACK);

            do {
                Shuffle(Letters, SIZE);
                if (MODE == "MEDIUM")
                    slideLeftDirection(Letters, SIZE);
                else
                    if (MODE == "HARD")
                        slide4Directions(Letters, SIZE);
            } while (!canSolve(Letters, SIZE, SIZE_BOARD, help1, help2));
        }

        do {
            system("cls");
            drawBoard(Letters, bg, SIZE, SIZE_BOARD);
            printInterface(player, score);
            firstCube = Selecting(Letters, bg, SIZE, secondCube, lockCube, help1, help2, score); // Set vị trí của [1stCube](cặp hiện tại) là của [2ndCube](cặp trước đó)
            drawCubeLock(Letters, firstCube); //Tô màu đỏ cho ô được chọn
            secondCube = Selecting(Letters, bg, SIZE, firstCube, firstCube, help1, help2, score);
            drawCubeLock(Letters, secondCube);
            prepareSelected(firstCube, secondCube); //Chuyển vị trí 2 ô 
        } while (!checkMatch(firstCube, secondCube, Letters, MODE, SIZE, SIZE_BOARD, score, time));

        if (MODE == "MEDIUM") //Slide board trước khi kiểm tra canSolve để không trả về sai giá trị help1, help2
            slideLeftDirection(Letters, SIZE);
        else
            if (MODE == "HARD")
                slide4Directions(Letters, SIZE);

        cube -= 2;
    }

    system("cls");
    drawBoard(Letters, bg, SIZE, SIZE_BOARD);
    printInterface(player, score);
    setColor(RED, BRIGHT_WHITE);
    moveCursorToXY(69, 9);
    cout << "YOU HAVE WON THE GAME";
    moveCursorToXY(64, 10);
    cout << "AUTOMATICALLY RETURN TO THE MENU";

    std::time_t end_time = std::time(nullptr);
    time = std::difftime(end_time, start_time);

    int idx = 0; //Index mặc định là của Level EASY
    if (MODE == "MEDIUM")
        idx = 1;
    else
        if (MODE == "HARD")
            idx = 2;

    if (score > player.level[idx].score) {
        player.level[idx].score = score;
        player.level[idx].time = time;
    }
    else
        if (score == player.level[idx].score && time < player.level[idx].time)
            player.level[idx].time = time;
            

    //All pairs are matched - Play sound win - Back to Menu
    PlaySound(TEXT("win.wav"), NULL, SND_ASYNC);
    Sleep(4700);
    return;
}

void printInterface(Player &player, int score)
{
    SetConsoleOutputCP(65001);

    moveCursorToXY(60, 4);
    setColor(BRIGHT_WHITE, BLACK);
    cout << "+--------------------------------------+" << endl;
    moveCursorToXY(60, 5);
    cout << "|                                      |" << endl;
    moveCursorToXY(60, 6);
    cout << "|                                      |" << endl;
    moveCursorToXY(60, 7);
    cout << "|                                      |" << endl;
    moveCursorToXY(60, 8);
    cout << "|                                      |" << endl;
    moveCursorToXY(60, 9);
    cout << "|                                      |" << endl;
    moveCursorToXY(60, 10);
    cout << "|                                      |" << endl;
    moveCursorToXY(60, 11);
    cout << "|                                      |" << endl;
    moveCursorToXY(60, 12);
    cout << "+--------------------------------------+" << endl;

    setColor(BRIGHT_WHITE, BLUE);
    moveCursorToXY(12 + 60, 5);
    cout << "GAME INFORMATION";

    setColor(BRIGHT_WHITE, PURPLE);
    moveCursorToXY(2 + 60, 6);
    cout << "Username: " << player.username;

    setColor(BRIGHT_WHITE, AQUA);
    moveCursorToXY(2 + 60, 7);
    cout << "Score: " << score;

    setColor(BRIGHT_WHITE, RED);
    moveCursorToXY(2 + 60, 8);
    cout << "Notification:";

    setColor(BRIGHT_WHITE, GREEN);
    moveCursorToXY(2 + 60, 11);
    cout << "Press H for Move Suggestion";
}
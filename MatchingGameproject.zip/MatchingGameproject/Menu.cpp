#include "Header.h"

void writeFile(Player* listPlayer)
{
    int n;
    ifstream ifs;
    ifs.open("records.dat", ios::binary);
    if (!ifs.is_open()) {
        cout << "Can't open file records.dat";
        return;
    }

    ifs.read(reinterpret_cast<char*>(&n), sizeof(n));
    ifs.close();

    fstream fs;
    fs.open("records.dat", ios::out | ios::binary | ios::trunc);

    if (!fs.is_open()) {
        cout << "Can't open file records.dat";
        return;
    }

    fs.write(reinterpret_cast<char*>(&n), sizeof(n)); // Write the number of players to the file

    for (int i = 0; i < n; i++) {
        fs.write((char*)&listPlayer[i], sizeof(Player));
    }

    fs.close();
}

Player* inputPlayerInfor(int &n)
{
    ifstream ifs("records.dat", ios::binary);

    if (!ifs.is_open()) {
        //cout << "Can't open file records.dat";
        return NULL;
    }

    ifs.read(reinterpret_cast<char*>(&n), sizeof(n)); // Read the number of players from the file
    Player* listPlayer = new Player[n];

    for (int i = 0; i < n; i++) {
        ifs.read(reinterpret_cast<char*>(&listPlayer[i]), sizeof(Player));
    }

    ifs.close();

    return listPlayer;
}

void printLogin()
{
    setColor(BRIGHT_WHITE, BLACK);
    SetConsoleOutputCP(65001);
    system("cls");

    moveCursorToXY(48, 7); 
    cout << "WELCOME TO THE LOGIN PAGE" << endl;

    moveCursorToXY(15, 10);
    cout << "╔════════════════════════════╗" << endl;

    moveCursorToXY(15, 11);
    cout << "║           LOGIN            ║" << endl;

    moveCursorToXY(15, 12);
    cout << "╚════════════════════════════╝" << endl;



    moveCursorToXY(75, 10);
    cout << "╔════════════════════════════╗" << endl;

    moveCursorToXY(75, 11);
    cout << "║          REGISTER          ║" << endl;

    moveCursorToXY(75, 12);
    cout << "╚════════════════════════════╝" << endl;

    moveCursorToXY(30, 16);
    cout << "Use ARROW KEYS to navigate and press ENTER to select an option!" << endl;
}

void selectingLogin()
{
    printLogin();
    int selectedOption = 1;
    moveCursorToXY(23, 11); cout << ">";

    do
    {
        PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
        if (selectedOption == 1) {
            moveCursorToXY(18 + (selectedOption - 1) * 60, 9); cout << "Already have an account?";
            moveCursorToXY(79, 9); cout << "                      ";
        }
        else 
            if (selectedOption == 2) {
            moveCursorToXY(19 + (selectedOption - 1) * 60, 9); cout << "New here? Sign up now!";
            moveCursorToXY(18, 9); cout << "                        ";
        }

        switch (inputKeyboard()) {
        case 2: // move Right
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            moveCursorToXY(23 + (selectedOption - 1) * 60, 11); cout << " "; // Delete the previous > 
            if (selectedOption > 1)
                selectedOption -= 1;
            else
                selectedOption = 2;
            moveCursorToXY(23 + (selectedOption - 1) * 60, 11); cout << ">"; // Draw the >              
            break;
        case 3: // move Left
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            moveCursorToXY(23 + (selectedOption - 1) * 60, 11); cout << " ";
            if (selectedOption < 2)
                selectedOption += 1;
            else
                selectedOption = 1;
            moveCursorToXY(23 + (selectedOption - 1) * 60, 11); cout << ">";
            break;
        case 5: // Enter
            PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
            switch (selectedOption) {
            case 1:
                login();
                break;
            case 2:
                registration();
                break;
            }
        default:
            break;
        }

    } while (true);
}

void login()
{
    bool found = false;
    int n;
    int index; //Index của player trong list

    string username, password;
    Player* listPlayer = inputPlayerInfor(n);

    system("cls");
    if (listPlayer == NULL) {
        moveCursorToXY(32, 7);
        cout << "There is no account yet, you must register an account!" << endl;
        Sleep(2000);
        selectingLogin();
    }
    moveCursorToXY(42, 7);
    cout << "Please Enter Username and Password!" << endl;

    moveCursorToXY(42, 9);
    cout << "Username: "; cin >> username;
    moveCursorToXY(42, 10);
    cout << "Password: ";

    // Hidden password
    while (true) {
        char ch = _getch();

        if (ch == 13) { // Enter
            break;
        }
        else if (ch == 8) { // Backspace 8 = \b
            if (password.length() > 0) {
                password.erase(password.length() - 1);
                cout << "\b \b";
            }
        }
        else { // Entering password
            password += ch;
            cout << "*";
        }
    }

    for (int i = 0; i < n; i++)
    {
        if (strcmp(listPlayer[i].username, username.c_str()) == 0 && strcmp(listPlayer[i].password, password.c_str()) == 0)
        {
            found = true;
            index = i; // The index of Player in list
            break;
        }
    }

    if (!found)
    {
        moveCursorToXY(54, 14);
        cout << "LOGIN ERROR";
        moveCursorToXY(40, 15);
        cout << "Please check your username and password!";

        Sleep(2000);
        selectingLogin();
    }
    else {
        printWelcome();
        selectingMenu(listPlayer, listPlayer[index]);
    }
}

void registration()
{
    int n = 1;
    string r_username, r_password;
    system("cls");

    moveCursorToXY(40, 7);
    cout << "Please Enter Username you want to use" << endl;
    moveCursorToXY(40, 8);
    cout << "Username: "; cin >> r_username;

    moveCursorToXY(40, 10);
    cout << "Provide your Password for the next Login" << endl;
    moveCursorToXY(40, 11);
    cout << "Password: "; cin >> r_password;

    fstream fs;
    fs.open("records.dat", ios::in | ios::out | ios::binary);
    if (!fs.is_open())
    {
        fs.open("records.dat", ios::out | ios::binary);
        if (!fs.is_open())
        {
            cout << "Can't open file records.dat";
            return;
        }

        fs.write((char*)&n, sizeof(int));
    }
    else
    {
        fs.read((char*)&n, sizeof(int));
        n = n + 1;
        fs.seekp(0);
        fs.write((char*)&n, sizeof(int));
        fs.seekp(0, ios::end);
    }

    Player newPlayer;
    strcpy(newPlayer.username, r_username.c_str());
    strcpy(newPlayer.password, r_password.c_str());

    for (int i = 0; i < 3; i++) {
        newPlayer.level[i].score = 0;
        newPlayer.level[i].time = 0;
    }

    fs.write((char*)&newPlayer, sizeof(Player));

    fs.close();
    
    moveCursorToXY(46, 14);
    cout << "Registration is Successful!";
    Sleep(2000);

    selectingLogin();
}

void printWelcome()
{
    PlaySound(TEXT("background.wav"), NULL, SND_ASYNC);  // Background sound
    srand(time(0));
    int count = 0;
    while (count < 15)
    {
        system("cls");
        for (int i = 0; i < 200; i++)
        {
            int x = rand() % 105;
            int y = rand() % 30;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), { (SHORT)x, (SHORT)y });
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), rand() % 16);
            cout << ".";
        }
        SetConsoleOutputCP(65001);
        cout << R"(
                                    ,___          .-;'           `;-.          ___,
                                     `"-.`\_...._/`.`             `.`\_...._/`.-"`
                                  ,      \        /                \        /      ,
                               .-' ',    / ()   ()\                /()   () \    .' `-._
                              `'._   \  /()    .  (|              |)  .    ()\  /   _.' 
                                  > .' ;,     -'-  /               \  -'-     ,; '. <
                                 / <   |;,     __.;                / ,    / ,  |.-'.-'
                                '-.'-.|  , \    , \             (_/    (_/ ,;|.<`
                                     `>.|;, \_)    \_)             \    ,     ;-`
                                     `-;     ,    /                 >   \    /
                                         '. <`'-,_)                 (_,-'`> .'
                                          '._)                           (_,'

                __      __          _                                               _             
                \ \    / / ___     | |     __      ___    _ __     ___      o O O  | |_     ___   
                 \ \/\/ / / -_)    | |    / _|    / _ \  | '  \   / -_)    o       |  _|   / _ \  
                  \_/\_/  \___|   _|_|_   \__|_   \___/  |_|_|_|  \___|   TS__[O]  _\__|   \___/  
                _|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""| {======|_|"""""|_|"""""| 
                "`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'./o--000'"`-0-0-'"`-0-0-' 

       ███    ███  █████ ████████  ██████  ██   ██ ██ ███    ██  ██████       ██████   █████  ███    ███ ███████
       ████  ████ ██   ██    ██    ██      ██   ██ ██ ████   ██ ██           ██       ██   ██ ████  ████ ██
       ██ ████ ██ ███████    ██    ██      ███████ ██ ██ ██  ██ ██   ███     ██   ███ ███████ ██ ████ ██ █████
       ██  ██  ██ ██   ██    ██    ██      ██   ██ ██ ██  ██ ██ ██    ██     ██    ██ ██   ██ ██  ██  ██ ██
       ██      ██ ██   ██    ██     ██████ ██   ██ ██ ██   ████  ██████       ██████  ██   ██ ██      ██ ███████

       )";
        Sleep(250);
        count++;
    }
}

void printMenu(Player &player) 
{
    SetConsoleOutputCP(65001);

    setColor(BRIGHT_WHITE, BLACK);
    system("cls");
    setColor(BRIGHT_WHITE, RED);
    /* R “()” cho phép định dạng một chuỗi theo cách không cần phải đặt các ký tự escape (\n, \t)
    để thể hiện các ký tự đặc biệt, thay vào đó ta có thể viết chuỗi một cách tự nhiên */
    cout << R"(
        ███╗   ███╗ █████╗ ████████╗ ██████╗██╗  ██╗██╗███╗   ██╗ ██████╗      ██████╗  █████╗ ███╗   ███╗███████╗
        ████╗ ████║██╔══██╗╚══██╔══╝██╔════╝██║  ██║██║████╗  ██║██╔════╝     ██╔════╝ ██╔══██╗████╗ ████║██╔════╝
        ██╔████╔██║███████║   ██║   ██║     ███████║██║██╔██╗ ██║██║  ███╗    ██║  ███╗███████║██╔████╔██║█████╗  
        ██║╚██╔╝██║██╔══██║   ██║   ██║     ██╔══██║██║██║╚██╗██║██║   ██║    ██║   ██║██╔══██║██║╚██╔╝██║██╔══╝  
        ██║ ╚═╝ ██║██║  ██║   ██║   ╚██████╗██║  ██║██║██║ ╚████║╚██████╔╝    ╚██████╔╝██║  ██║██║ ╚═╝ ██║███████╗
        ╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝    ╚═════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝      ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝
    )"; 
    cout << R"(
             _  _              _       _                             __      __                   _           
            | || |    ___     | |     | |     ___      o O O         \ \    / / ___      _ _   __| |    ___   
            | __ |   / -_)    | |     | |    / _ \    o               \ \/\/ / / _ \    | '_| / _` |   (_-<   
            |_||_|   \___|   _|_|_   _|_|_   \___/   TS__[O]  TS__[O]  \_/\_/  \___/   _|_|_  \__,_|   /__/_  
           _|"""""|_|"""""|_|"""""|_|"""""|_|"""""| {======| {======|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""| 
           "`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'./o--000'./o--000'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-' 
    )";

    setColor(BRIGHT_WHITE, PURPLE);
    // Print the menu
    moveCursorToXY(47, 15);
    cout << player.username << ", welcome to the Game!";

    setColor(BRIGHT_WHITE, BLACK);
    moveCursorToXY(30, 16);
    cout << "Use ARROW KEYS to navigate and press ENTER to select an option!" << endl;

    moveCursorToXY(45, 17);
    cout << "╔════════════════════════════╗" << endl;

    moveCursorToXY(45, 18);
    cout << "║         PLAY GAME          ║" << endl;

    moveCursorToXY(45, 19);
    cout << "╠════════════════════════════╣" << endl;

    moveCursorToXY(45, 20);
    cout << "║         HOW TO PLAY        ║" << endl;

    moveCursorToXY(45, 21);
    cout << "╠════════════════════════════╣" << endl;

    moveCursorToXY(45, 22);
    cout << "║         LEADERBOARD        ║" << endl;

    moveCursorToXY(45, 23);
    cout << "╠════════════════════════════╣" << endl;

    moveCursorToXY(45, 24);
    cout << "║         QUIT               ║" << endl;

    moveCursorToXY(45, 25);
    cout << "╚════════════════════════════╝" << endl;
}


void selectingMenu(Player* listPlayer, Player &player)
{
    printMenu(player);
    int selectedOption = 1;
    moveCursorToXY(47, 16 + selectedOption * 2); cout << ">";

    while (true)
    {
        PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
        switch (inputKeyboard()) {
        case 1: // move Up
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            moveCursorToXY(47, 16 + selectedOption * 2); cout << " "; // Delete the previous > 
            if (selectedOption > 1)
                selectedOption -= 1;
            else
                selectedOption = 4;
            moveCursorToXY(47, 16 + selectedOption * 2); cout << ">"; // Draw the > 
            break;
        case 4: // move Down
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            moveCursorToXY(47, 16 + selectedOption * 2); cout << " ";
            if (selectedOption < 4)
                selectedOption += 1;
            else
                selectedOption = 1;
            moveCursorToXY(47, 16 + selectedOption * 2); cout << ">";
            break;
        case 5: // Enter
            PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
            switch (selectedOption) {
            case 1:
                playGame(player);
                writeFile(listPlayer);
                selectingMenu(listPlayer, player);
                break;
            case 2:
                howToPlay();
                selectingMenu(listPlayer, player);
                break;
            case 3:
                leaderboard(listPlayer);
                selectingMenu(listPlayer, player);
                break;
            case 4:
                delete[] listPlayer;
                exitGame();
                exit(0);
                break;
            default:
                break;
            }
        default:
            break;
        }
    }
}

void loadingBar()
{
    system("cls");

    moveCursorToXY(55, 9);
    cout << "LOADING...";
	
    moveCursorToXY(50, 10);
	for (int i = 0; i < 20; i++)
	{
        cout << "█";
		Sleep(50);
	}

    system("cls");
}

void printMode()
{
    system("cls");
    
    moveCursorToXY(45, 8);
    cout << "Please Select the mode:";

    moveCursorToXY(45, 9);
    cout << "╔════════════════════════════╗" << endl;

    moveCursorToXY(45, 10);
    cout << "║         EASY               ║" << endl;

    moveCursorToXY(45, 11);
    cout << "╠════════════════════════════╣" << endl;

    moveCursorToXY(45, 12);
    cout << "║         MEDIUM             ║" << endl;

    moveCursorToXY(45, 13);
    cout << "╠════════════════════════════╣" << endl;

    moveCursorToXY(45, 14);
    cout << "║         HARD               ║" << endl;

    moveCursorToXY(45, 15);
    cout << "╚════════════════════════════╝" << endl;
}

void playGame(Player &player) 
{
    system("cls");
    int mode = 1;
    bool flag = false;
    printMode();
    moveCursorToXY(47, 8 + mode * 2); cout << ">";

    PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);

    do
    {
        switch (inputKeyboard()) {
        case 1: // move Up
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            moveCursorToXY(47, 8 + mode * 2); cout << " "; // Delete the previous > 
            if (mode > 1)
                mode -= 1;
            else
                mode = 3;
            moveCursorToXY(47, 8 + mode * 2); cout << ">"; // Draw the following > 
            break;
        case 4: // move Down
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            moveCursorToXY(47, 8 + mode * 2); cout << " ";
            if (mode < 3)
                mode += 1;
            else
                mode = 1;
            moveCursorToXY(47, 8 + mode * 2); cout << ">";
            break;
        case 5: // Enter
            PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
            switch (mode) {
            case 1: // Mode EASY
                loadingBar();
                startGame("EASY", player);
                break;
            case 2: // Mode MEDIUM
                loadingBar();
                startGame("MEDIUM", player);
                break;
            case 3:
                loadingBar();
                startGame("HARD", player);
            default:
                break;
            }
            flag = true;
        default:
            break;
        }
    } while (!flag);
}

void howToPlay() // How to play instructions go here
{
    system("cls");
    moveCursorToXY(4, 2);
    setColor(RED, BRIGHT_WHITE); cout << "INTRODUCTION"; setColor(BRIGHT_WHITE, BLACK);
    moveCursorToXY(18, 2);
    cout << "The MATCHING GAME consists of a grid of tiles. Each tile has a LETTER on it"; //
    moveCursorToXY(18, 4);
    cout << "The goal of the game is to match pairs of tiles with the same letter";
    moveCursorToXY(18, 5);
    cout << "If they do not match, you must try again!";
    moveCursorToXY(18, 6);
    cout << "The game ends when all tiles have been MATCHED!";

    moveCursorToXY(4, 8);
    setColor(RED, BRIGHT_WHITE); cout << "HOW TO PLAY ";  setColor(BRIGHT_WHITE, BLACK);
    moveCursorToXY(18, 8);
    cout << "Use ARROW KEYS or WASD KEYS to navigate and press ENTER to select the Cube.";

    setColor(BRIGHT_WHITE, BLUE);
    moveCursorToXY(18, 10);
    cout << "There are 4 ways to match pairs of tiles:";

    setColor(BRIGHT_WHITE, RED);
    moveCursorToXY(18, 11);
    cout << "I Matching: (+1 point)";
    moveCursorToXY(18, 12);
    cout << "L Matching: (+2 points)";
    moveCursorToXY(18, 13);
    cout << "Z Matching: (+3 points)";
    moveCursorToXY(18, 14);
    cout << "U Matching: (+4 points)";

    setColor(BRIGHT_WHITE, BLACK);
    moveCursorToXY(18, 16);
    cout << "You can also use the ";
    setColor(BRIGHT_WHITE, GREEN); cout << "MOVE SUGGESTION";
    setColor(BRIGHT_WHITE, BLACK);
    cout << " feature by pressing H";
    moveCursorToXY(18, 17);
    cout << "(Note that your score will be decreased by 2 points)";

    moveCursorToXY(18, 19);
    cout << "The game board will automatically ";
    setColor(BRIGHT_WHITE,  RED); cout << "SHUFFLE";
    setColor(BRIGHT_WHITE, BLACK);
    cout << " if there are no moves left, ";
    moveCursorToXY(18, 20);
    cout << "and your score will be decreased if you are playing on ";
    setColor(BRIGHT_WHITE, RED); cout << "MEDIUM or HARD";
    setColor(BRIGHT_WHITE, BLACK);
    cout << " mode. ";

    moveCursorToXY(18, 21);
    cout << "Selecting the "; 
    setColor(BRIGHT_WHITE, RED); cout << "WRONG MATCH";
    setColor(BRIGHT_WHITE, BLACK);
    cout << " will also decrease your score, so "; 
    setColor(BRIGHT_WHITE, RED); cout << "BE CAREFUL!";


    setColor(BRIGHT_WHITE, BLACK);
    moveCursorToXY(44, 25);
    cout << "Press ENTER to return to the Menu";
    switch (inputKeyboard()) {
    case 5:
        return;
        break;
    default:
        break;
    }
}

void leaderboard(Player* listPlayer)
{
    string MODE;

    system("cls");
    setColor(BRIGHT_WHITE, BLACK);
    printMode();
    bool flag = false; // end do{ }while; loop
    int mode = 1;
    moveCursorToXY(47, 8 + mode * 2); cout << ">";

    do //Chọn Mode muốn xem
    {
        switch (inputKeyboard()) {
        case 1: // move Up
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            moveCursorToXY(47, 8 + mode * 2); cout << " "; // Delete the previous > 
            if (mode > 1)
                mode -= 1;
            else
                mode = 3;
            moveCursorToXY(47, 8 + mode * 2); cout << ">"; // Draw the following > 
            break;
        case 4: // move Down
            PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
            moveCursorToXY(47, 8 + mode * 2); cout << " ";
            if (mode < 3)
                mode += 1;
            else
                mode = 1;
            moveCursorToXY(47, 8 + mode * 2); cout << ">";
            break;
        case 5: // Enter
            PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
            switch (mode) {
            case 1:
                MODE = "EASY";
                break;
            case 2:
                MODE = "MEDIUM";
                break;
            case 3:
                MODE = "HARD";
                break;
            }
            flag = true;
        default:
            break;
        }
    } while (!flag);

    system("cls");

    setColor(BRIGHT_WHITE, RED);
    SetConsoleOutputCP(65001);
    cout << R"(    
            ██╗     ███████╗ █████╗ ██████╗ ███████╗██████╗ ██████╗  ██████╗  █████╗ ██████╗ ██████╗ 
            ██║     ██╔════╝██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
            ██║     █████╗  ███████║██║  ██║█████╗  ██████╔╝██████╔╝██║   ██║███████║██████╔╝██║  ██║
            ██║     ██╔══╝  ██╔══██║██║  ██║██╔══╝  ██╔══██╗██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
            ███████╗███████╗██║  ██║██████╔╝███████╗██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
            ╚══════╝╚══════╝╚═╝  ╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ 
    )";

    setColor(BRIGHT_WHITE, BLUE);
    moveCursorToXY(25, 10);
    cout << "No.";

    moveCursorToXY(35, 10);
    cout << "Username";

    moveCursorToXY(55, 10);
    cout << "Score";

    moveCursorToXY(70, 10);
    cout << "Time played";

    setColor(BRIGHT_WHITE, BLACK);

    // Lấy số phần tử list từ file
    int n;
    ifstream ifs;
    ifs.open("records.dat", ios::binary);
    if (!ifs.is_open())
    {
        cout << "Can't open file records.txt";
        return;
    }

    ifs.read(reinterpret_cast<char*>(&n), sizeof(n));
    ifs.close();

    Player* rank = new Player[n];

    // Arrange rank
    for (int i = 0; i < n; i++)
        rank[i] = listPlayer[i];

    int idx = 0; //Index của level easy
    if (MODE == "MEDIUM")
        idx = 1;
    else
        if (MODE == "HARD")
            idx = 2;
        
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (rank[j].level[idx].score > rank[i].level[idx].score)
                swap(rank[i], rank[j]);
        }
    }

    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if ((rank[j].level[idx].score == rank[i].level[idx].score) && (rank[j].level[idx].time < rank[i].level[idx].time))
                swap(rank[i], rank[j]);
        }
    }

    int numbers = 5; //Số lượng tài khoản tối đa in trên leaderboard
    if (n < 5)
        numbers = n;

    //Print rank
    for (int i = 0; i < numbers; i++)
    {
        moveCursorToXY(25, 13 + i * 2);
        cout << i + 1 << ".";

        moveCursorToXY(35, 13 + i * 2);
        cout << rank[i].username;
        
        moveCursorToXY(56, 13 + i * 2);
        cout << rank[i].level[idx].score;

        moveCursorToXY(73, 13 + i * 2);
        cout << setw(2) << setfill('0') << rank[i].level[idx].time / 60 << ":" << setw(2) << setfill('0') << rank[i].level[idx].time % 60;
    }

    moveCursorToXY(44, 25);
    cout << "Press ENTER to return to the Menu";
    switch (inputKeyboard()) {
    case 5:
        PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
        delete[] rank;
        return;
        break;
    default: 
        PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
        break;
    }
}

void exitGame()
{
    system("cls");
    moveCursorToXY(49, 14);
    cout << "THANK YOU FOR PLAYING";
    moveCursorToXY(56, 15);
    cout << "GOODBYE!";

    moveCursorToXY(0, 27); //Move the exit noti to end of console
    return;
}

void startGame(string MODE, Player &player)
{
    int SIZE = EASY; //Mặc định = 4 
    if (MODE == "MEDIUM")
            SIZE = MEDIUM;
        else
            if (MODE == "HARD")
                SIZE = HARD;

    int SIZE_BOARD = SIZE + 2;

    string** bg = storeBackground(MODE);

    char** Letters = new char* [SIZE_BOARD];

    for (int i = 0; i < SIZE_BOARD; i++) {
        Letters[i] = new char[SIZE_BOARD];
    }

    Matching(Letters, bg, MODE, SIZE, SIZE_BOARD, player);

    for (int i = 0; i < SIZE * 3; i++) {
        delete[] bg[i];
    }
    delete[] bg;

    for (int i = 0; i < SIZE_BOARD; i++) {
        delete[] Letters[i];
    }
    delete[] Letters;

    return;
}


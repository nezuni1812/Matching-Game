﻿#ifndef HEADERFILE_H
#define HEADERFILE_H

#pragma warning(disable:4996)
#pragma comment(lib, "winmm.lib")

#include <iostream>
#include <iomanip>
#include <cstdlib>     // For abs

#include <windows.h>   // For SetConsoleOutputCP() and Sleep()
#include <conio.h>     // For _getch() function
#include <mmsystem.h>  // For PlaySound() function
#include <stdio.h>     // For system(“cls”), system(“pause”) and exit(0)

#include <chrono> //For time

#include <stdlib.h> 

#include <ctime>       // For random, for time

#include <fstream>     // For file player account, background
#include <string>
#include <string.h> //For c string

#define EASY 4
#define MEDIUM 6
#define HARD 6

//Color Code
#define BLACK 0
#define BLUE 1
#define GREEN 2
#define AQUA 3
#define RED 4
#define PURPLE 5
#define YELLOW 6
#define WHITE 7
#define GRAY 8
#define LIGHT_BLUE 9
#define LIGHT_GREEN 10
#define LIGHT_AQUA 11
#define LIGHT_RED 12
#define LIGHT_PURPLE 13
#define LIGHT_YELLOW 14
#define BRIGHT_WHITE 15

using namespace std;

struct Level {
    int score;
    int time; //seconds
};

struct Player {
    char username[20];
    char password[20];
    Level level[3]; //3 level
};

struct Cube
{
    int y, x;
};

void printLogin();
void selectingLogin();

Player* inputPlayerInfor(int& n);
void login();
void registration();
void writeFile(Player* listPlayer);

void printWelcome();
void printMenu(Player &player);
void selectingMenu(Player* listPlayer, Player& player);

void loadingBar();
void printMode();
void playGame(Player& player);

void howToPlay();
void leaderboard(Player* listPlayer);
void exitGame();

void startGame(string MODE, Player &player);
void prepareSelected(Cube& p1, Cube& p2);

void Shuffle(char** Letters, int SIZE);
void getLetters(char**& Letters, int SIZE, int SIZE_BOARD);

bool canSolve(char** Letters, int SIZE, int SIZE_BOARD, Cube& help1, Cube& help2);
bool checkSolve(Cube p1, Cube p2, char** Letters, int SIZE);

bool checkY(int x1, int y1, int x2, int y2, char** Letters);
bool checkX(int x1, int y1, int x2, int y2, char** Letters);

bool checkI(Cube p1, Cube p2, char** Letters);
bool checkL(Cube p1, Cube p2, char** Letters);
bool checkZ(Cube p1, Cube p2, char** Letters);
bool checkU(Cube p1, Cube p2, char** Letters, int SIZE_BOARD);

void slideLeftDirection(char** Letters, int SIZE);
void slide4Directions(char** Letters, int SIZE);

void setConsole();
void hideCursor();

void setColor(int background_color, int text_color);

int inputKeyboard();
void moveCursorToXY(int x, int y);

int calCubeWidth(int PosX);
int calCubeHeight(int PosY);

void movetoMiddleTopCube(Cube p);
void movetoMiddleBotCube(Cube p);
void movetoMiddleRightCube(Cube p);
void movetoMiddleLeftCube(Cube p);

string** storeBackground(string MODE);
void drawBackground(int SIZE, string** bg, int i, int j);

void drawHeader();
void drawFooter();
void drawRowMid(char** Letters, int i, int j);
void drawRowMidChosen(char** Letters, int i, int j);
void printSpace();

void drawHorizontalLine(int x1, int x2);
void drawVerticalLine(int x1, int y1, int x2, int y2);

void drawILine(Cube p1, Cube p2, char** Letters);
void drawLLine(Cube p1, Cube p2, char** Letters);
void drawZLine(Cube p1, Cube p2, char** Letters);
void drawULine(Cube p1, Cube p2, char** Letters, int SIZE_BOARD);

void drawBackgroundDeleted(string** bg, int i, int j);
void drawCube(char** Letters, string** bg, Cube previous);
void drawCubeChosen(char** Letters, string** bg, Cube selecting);
void drawCubeLock(char** Letters, Cube selected);
void drawCubeSuggest(char** Letters, Cube suggested);

void drawBoard(char** Letters, string** bg, int SIZE, int SIZE_BOARD);
void printInterface(Player& player, int score);

bool checkMatch(Cube p1, Cube p2, char** Letters, string MODE, int SIZE, int SIZE_BOARD, int &score, int &time);
Cube Selecting(char** Letters, string** bg, int SIZE, Cube selecting, Cube lockCube, Cube help1, Cube help2, int &score);
void Matching(char** Letters, string** bg, string MODE, int SIZE, int SIZE_BOARD, Player& player);

#endif
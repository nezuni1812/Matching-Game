#include "Header.h"

int main()
{
    setColor(BRIGHT_WHITE, BLACK);
    hideCursor();
    selectingLogin();
    return 0;
}
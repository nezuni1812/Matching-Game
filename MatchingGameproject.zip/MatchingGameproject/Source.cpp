﻿#include "Header.h"

void prepareSelected(Cube& p1, Cube& p2)
{
    if (p1.x == p2.x && p1.y == p2.y) 
        return;

    if (p1.x < p2.x && p1.y > p2.y) 
    {
        return;
    }
    else 
        if (p1.x > p2.x)
        {
            swap(p1, p2);
            return;
        }
        else
            if (p1.y > p2.y) //p1.x == p2.x
            {
                swap(p1, p2);
                return;
            }
}

bool checkY(int x1, int y1, int x2, int y2, char** Letters)
{

    if (y1 != y2)
        return false;

    if (x2 < x1)
        swap(x1, x2);
    for (int x = x1 + 1; x < x2; x++)
        if (Letters[y1][x] != ' ')
            return false;

    return true;
}

bool checkX(int x1, int y1, int x2, int y2, char** Letters)
{
    if (x1 != x2)
        return false;

    if (y2 < y1)
        swap(y1, y2);
    for (int y = y1 + 1; y < y2; y++)
        if (Letters[y][x1] != ' ')
            return false;

    return true;
}

bool checkI(Cube p1, Cube p2, char** Letters)
{
    if (checkX(p1.x, p1.y, p2.x, p2.y, Letters) || checkY(p1.x, p1.y, p2.x, p2.y, Letters))
        return true;
    else
        return false;
}

bool checkL(Cube p1, Cube p2, char** Letters)
{
    if ((checkY(p1.x, p1.y, p2.x, p1.y, Letters) && checkX(p2.x, p1.y, p2.x, p2.y, Letters) && Letters[p1.y][p2.x] == ' ')
        || (checkX(p1.x, p1.y, p1.x, p2.y, Letters) && checkY(p1.x, p2.y, p2.x, p2.y, Letters) && Letters[p2.y][p1.x] == ' '))
        return true;
    else
        return false;
}

bool checkZ(Cube p1, Cube p2, char** Letters)
{
    Cube pMinY = p1, pMaxY = p2;
    if (p1.y > p2.y) {
        pMinY = p2;
        pMaxY = p1;
    }

    for (int y = pMinY.y + 1; y < pMaxY.y; y++) { 
        if (Letters[y][pMinY.x] == ' ' && Letters[y][pMaxY.x] == ' ') {
            if (checkX(pMinY.x, pMinY.y, pMinY.x, y, Letters)
                && checkY(pMinY.x, y, pMaxY.x, y, Letters)
                && checkX(pMaxY.x, y, pMaxY.x, pMaxY.y, Letters))
                return true;
        }
    }

    Cube pMinX = p1, pMaxX = p2;
    if (p1.x > p2.x) {
        pMinY = p2;
        pMaxY = p1;
    }

    for (int x = pMinX.x + 1; x < pMaxX.x; x++) {
        if (Letters[pMinX.y][x] == ' ' && Letters[pMaxX.y][x] == ' ') {
            if (checkY(pMinX.x, pMinX.y, x, pMinX.y, Letters)
                && checkX(x, pMinX.y, x, pMaxX.y, Letters)
                && checkY(x, pMaxX.y, pMaxX.x, pMaxX.y, Letters))
                return true;
        }
    }

    return false;
}

bool checkU(Cube p1, Cube p2, char** Letters, int SIZE_BOARD)
{
    Cube pMinY = p1, pMaxY = p2;
    if (p1.y > p2.y) {
        pMinY = p2;
        pMaxY = p1;
    }

    for (int y = pMinY.y - 1; y >= 0; y--) { //U ngửa dưới                      
        if (Letters[y][pMinY.x] == ' ' && Letters[y][pMaxY.x] == ' ') {
            if (checkX(pMinY.x, pMinY.y, pMinY.x, y, Letters)
                && checkY(pMinY.x, y, pMaxY.x, y, Letters)
                && checkX(pMaxY.x, y, pMaxY.x, pMaxY.y, Letters)) 
                return true;
            
        }
    }

    for (int y = pMinY.y + 1; y < SIZE_BOARD; y++) { //U ngửa trên                      
        if (Letters[y][pMinY.x] == ' ' && Letters[y][pMaxY.x] == ' ') {
            if (checkX(pMinY.x, pMinY.y, pMinY.x, y, Letters)
                && checkY(pMinY.x, y, pMaxY.x, y, Letters)
                && checkX(pMaxY.x, y, pMaxY.x, pMaxY.y, Letters))
                return true;
        }
    }

    Cube pMinX = p1, pMaxX = p2;
    if (p1.x > p2.x) {
        pMinY = p2;
        pMaxY = p1;
    }

    for (int x = pMinX.x - 1; x >= 0; x--) { //U ngửa phải
        if (Letters[pMinX.y][x] == ' ' && Letters[pMaxX.y][x] == ' ') {
            if (checkY(pMinX.x, pMinX.y, x, pMinX.y, Letters)
                && checkX(x, pMinX.y, x, pMaxX.y, Letters)
                && checkY(x, pMaxX.y, pMaxX.x, pMaxX.y, Letters))
                return true;
        }
    }

    for (int x = pMinX.x + 1; x < SIZE_BOARD; x++) { //U ngửa trái
        if (Letters[pMinX.y][x] == ' ' && Letters[pMaxX.y][x] == ' ') {
            if (checkY(pMinX.x, pMinX.y, x, pMinX.y, Letters)
                && checkX(x, pMinX.y, x, pMaxX.y, Letters)
                && checkY(x, pMaxX.y, pMaxX.x, pMaxX.y, Letters))
                return true;
        }
    }

    return false;
}

bool checkSolve(Cube p1, Cube p2, char** Letters, int SIZE)
{
    if ((Letters[p1.y][p1.x] == Letters[p2.y][p2.x]) && (Letters[p1.y][p1.x] != ' ') && (p1.x != p2.x || p1.y != p2.y)) {
        if (checkI(p1, p2, Letters))
            return true;
        else {
            if (checkL(p1, p2, Letters))
                return true;
            else {
                if (checkZ(p1, p2, Letters))
                    return true;
                else {
                    if (checkU(p1, p2, Letters, SIZE))
                        return true;
                    else
                        return false;
                }
            }
        }
    }
    else
        return false;
}

//Đảo thứ tự các chữ
void Shuffle(char** Letters, int SIZE)
{
    for (int i = 1; i <= SIZE; i++)
        for (int j = 1; j <= SIZE; j++)
        {
            int r = rand() % SIZE + 1;
            int c = rand() % SIZE + 1;
            swap(Letters[i][j], Letters[r][c]);
        }
}

void getLetters(char**& Letters, int SIZE, int SIZE_BOARD)
{
    srand(time(0));
    Letters = new char* [SIZE_BOARD];
    for (int i = 0; i < SIZE_BOARD; i++)
        Letters[i] = new char[SIZE_BOARD];

    //Gán toàn bộ phần tử bằng ' ' để dễ thao tác với trò chơi
    for (int a = 0; a < SIZE_BOARD; a++)
        for (int b = 0; b < SIZE_BOARD; b++)
            Letters[a][b] = ' ';

    //Tạo ngẫu nhiên một mảng gồm những cặp chữ giống nhau nằm kế nhau
    for (int a = 1; a <= SIZE; a++)
        for (int b = 1; b <= SIZE; b += 2)
            Letters[a][b] = Letters[a][b + 1] = rand() % 26 + 'A';
    //Đảo vị trí các chữ
    Shuffle(Letters, SIZE);
}

//Kiểm tra xem ma trận có giải được không
bool canSolve(char** Letters, int SIZE, int SIZE_BOARD, Cube& help1, Cube& help2)
{
    for (int i = 1; i <= SIZE; i++)
        for (int j = 1; j <= SIZE; j++)
            if (Letters[i][j] != ' ')
            {
                help1 = { i, j };
                for (int m = i; m <= SIZE; m++)
                    for (int n = (m == i) ? j + 1 : 1; n <= SIZE; n++) 
                        {
                            help2 = { m, n };
                            if (checkSolve(help1, help2, Letters, SIZE))
                                return true;
                        }
            }

    return false;
}

void slideLeftDirection(char** Letters, int SIZE) {
    for (int i = 1; i <= SIZE; i++)
        for (int m = SIZE; m >= 1; m--)
            for (int n = 2; n <= m; n++)
                if (Letters[i][n - 1] == ' ')
                    swap(Letters[i][n - 1], Letters[i][n]);
}

void slide4Directions(char** Letters, int SIZE) {
    for (int i = 1; i <= SIZE; i++) //Slide Left
        for (int m = SIZE / 2; m >= 1; m--)
            for (int n = 2; n <= m; n++)
                if (Letters[i][n - 1] == ' ')
                    swap(Letters[i][n - 1], Letters[i][n]);

    for (int i = 1; i <= SIZE; i++) //Slide Right
        for (int m = SIZE /2 + 1; m <= SIZE; m++)
            for (int n = SIZE / 2 + 2; n >= m; n--) 
                if (Letters[i][n + 1] == ' ') 
                    swap(Letters[i][n], Letters[i][n + 1]);

    for (int i = 1; i <= SIZE; i++) //Slide Up
        for (int m = SIZE / 2; m >= 1; m--)
            for (int n = 2; n <= m; n++)
                if (Letters[n - 1][i] == ' ')
                    swap(Letters[n - 1][i], Letters[n][i]);

    for (int i = 1; i <= SIZE; i++) //Slide down
        for (int m = SIZE / 2 + 1; m <= SIZE; m++)
            for (int n = SIZE / 2 + 2; n >= m; n--)
                if (Letters[n + 1][i] == ' ')
                    swap(Letters[n][i], Letters[n + 1][i]);
}
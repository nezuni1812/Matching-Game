﻿#ifndef HEADERFILE_H
#define HEADERFILE_H

#include "Source.h"
#include <iostream>
#include <iomanip>
#include <cstdlib> //for abs

using namespace std;

//https://stackoverflow.com/questions/23860284/most-efficient-possible-code-for-printing-a-specific-board-c

void drawHeader();

void drawFooter();

void drawRowMid(char** Letters, int i, int j);
void drawRowMidChosen(char** Letters, int i, int j);
void drawRow();

void printSpace();

void drawRowLine(int x1, int x2);
void drawColLine(int x1, int y1, int x2, int y2);

//void drawILine(Cube p1, Cube p2, char** Letters);

//Set lại màu trắng cho Cube
void drawCube(char** Letters, Cube previous);

//Set blue cho Cube đang trỏ tới
void drawCubeChosen(char** Letters, Cube selecting);
//Set màu đỏ cho Cube bị lock
void drawCubeLock(char** Letters, Cube selected);

//Set green cho Cube suggest
void drawCubeSuggest(char** Letters, Cube suggested);

void drawBoard(char** Letters, int SIZE, int SIZE_BOARD);

bool checkMatch(Cube p1, Cube p2, char** Letters, int SIZE_BOARD);

Cube Selecting(char** Letters, int SIZE, Cube selecting, Cube lockCube, Cube help1, Cube help2);

void Matching(char** Letters, int SIZE, int SIZE_BOARD);

//void printRectangle(int left, int top, int width, int height);
//void printInterface();

#endif
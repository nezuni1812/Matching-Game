#ifndef HEADERFILE_H
#define HEADERFILE_H

#include "Board.h"
#include <iostream>
#include <iomanip>
#include <windows.h>
#include <ctime>
#include <conio.h> // For _getch() function
#include <mmsystem.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

void printMenu();
void selectingMenu();

void loadingBar();
void printMode();
void playGame();

void howToPlay();
void leaderBoard();
void exitGame();

void startGame(int DIFFICULTY);

#endif
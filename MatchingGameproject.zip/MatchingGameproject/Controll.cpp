﻿#include "Header.h"

HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE); // Con trỏ xử lí output console

void setConsole() {
    system("mode con: cols=120 lines=40");
}

/*void playSound(int i) {
    // Define an array of sound file names using wide character strings
    const wchar_t* soundFile[] = { L"move.wav", L"enter.wav", L"error.wav", L"win.wav", L"background.wav" };
    PlaySound(soundFile[i], NULL, SND_FILENAME | SND_ASYNC);
}*/
/*PlaySound(TEXT("move.wav"), NULL, SND_ASYNC);
PlaySound(TEXT("enter.wav"), NULL, SND_ASYNC);
PlaySound(TEXT("error.wav"), NULL, SND_ASYNC);
PlaySound(TEXT("win.wav"), NULL, SND_ASYNC);
PlaySound(TEXT("bakcground.wav"), NULL, SND_ASYNC);*/
void setColor(int background_color, int text_color)
{   // Get a handle to the console output
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    int colorAttribute = background_color * 16 + text_color;
    SetConsoleTextAttribute(hConsole, colorAttribute);
}

int inputKeyboard()
{
    int c = _getch();
    if (c == 0 || c == 224) // Arrow key detected
    {
        c = _getch();       // Read Arrow key
        if (c == 72)        // KEY_UP
            return 1;
        else if (c == 75)   // KEY_LEFT
            return 2;
        else if (c == 77)   // KEY_RIGHT
            return 3;
        else if (c == 80)   // KEY_DOWN
            return 4;
    }
    else {
        if (c == 'W' || c == 'w') // UP
            return 1;
        else if (c == 'A' || c == 'a') // LEFT
            return 2;
        else if (c == 'D' || c == 'd') // RIGHT
            return 3;
        else if (c == 'S' || c == 's') // DOWN 
            return 4;
        else if (c == 13)              // Enter
            return 5;
        else if (c == 'H' || c == 'h') // Help
            return 6;
    }
}

// move cursor
void moveCursorToXY(int x, int y)
{
    COORD Position;
    Position.X = x;
    Position.Y = y;
    SetConsoleCursorPosition(hStdOut, Position);
}

void hideCursor()
{
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE); // Get the console output handle
    CONSOLE_CURSOR_INFO cursorInfo;
    cursorInfo.dwSize = 1;
    cursorInfo.bVisible = FALSE;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);      // Set the cursor visibility to false
}

int calCubeWidth(int PosX)
{
    return PosX * 7; // Mỗi ô nằm ngang cách nhau 7 
}

int calCubeHeight(int PosY)
{
    return PosY * 3; // Mỗi ô nằm dọc cách nhau 3
}

//Di chuyển tới vị trí center của 1 trong 4 cạnh của cube
void movetoMiddleTopCube(Cube p) 
{
    int x = p.x * 7 + 3;
    int y = p.y * 3;
    moveCursorToXY(x, y);
}

void movetoMiddleBotCube(Cube p)
{
    int x = p.x * 7 + 3;
    int y = p.y * 3 + 2;
    moveCursorToXY(x, y);
}

void movetoMiddleRightCube(Cube p)
{
    int x = p.x * 7 + 6;
    int y = p.y * 3 + 1;
    moveCursorToXY(x, y);
}

void movetoMiddleLeftCube(Cube p)
{
    int x = p.x * 7;
    int y = p.y * 3 + 1;
    moveCursorToXY(x, y);
}
